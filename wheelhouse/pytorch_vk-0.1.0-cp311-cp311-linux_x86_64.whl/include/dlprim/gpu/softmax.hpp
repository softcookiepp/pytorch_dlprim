#pragma once
#include <dlprim/context.hpp>
#include <dlprim/tensor.hpp>


namespace dlprim
{

namespace gpu
{

enum class SoftmaxEpilogue
{
	eForward = 1,
	eBackward = 2,
	eLogForward = 3,
	eLogBackward = 4
};

void spatial_softmax(
	const ExecutionContext& e,
	const DataType dtype,
	const SoftmaxEpilogue epilogue,
	const tart::buffer_ptr& output_buffer,
	const uint32_t output_offset,
	const tart::buffer_ptr& input_buffer,
	const uint32_t input_offset,
	const uint32_t outer_size,
	const uint32_t dim_size,
	const uint32_t inner_size,
	const bool half_to_float);

void spatial_softmax_backward(
	const ExecutionContext& e,
	const DataType dtype,
	const SoftmaxEpilogue epilogue,
	const tart::buffer_ptr& gI,
	uint32_t gI_offset,
	const tart::buffer_ptr& output,
	uint32_t output_offset,
	const tart::buffer_ptr& grad,
	uint32_t grad_offset,
	uint32_t outer_size,
	uint32_t dim_size,
	uint32_t inner_size,
	bool half_to_float);

} // namespace gpu

} // namespace dlprim
